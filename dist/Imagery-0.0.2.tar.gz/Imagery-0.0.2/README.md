This is a simple package which aims at providing basic preprocessing to images.
Want to see more features? 
Coming your way right away!
Feel free to Fork!
